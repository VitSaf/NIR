# esp8266_stdout
A clone of Jeroen Domburg's (<jeroen@spritesmods.com>) stdout driver.
It's an alternative uart driver that only uses the TX pin, so the RX pin is free for GPIO use.

Needless to say, but this driver can only transmit.

###License:
  "THE BEER-WARE LICENSE" (Revision 42):
  Jeroen Domburg <jeroen@spritesmods.com> wrote this file. As long as you retain 
  this notice you can do whatever you want with this stuff. If we meet some day, 
  and you think this stuff is worth it, you can buy me a beer in return. 


